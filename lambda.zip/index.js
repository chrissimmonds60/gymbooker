const chromium = require('chrome-aws-lambda');
const puppeteer = require('puppeteer-core');

exports.handler = async (event) => {
  let browser = null;

  try {
    browser = await puppeteer.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath || '/usr/bin/chromium-browser',
      headless: chromium.headless,
      ignoreHTTPSErrors: true,
    });

    const page = await browser.newPage();

    await page.goto('https://www.virginactive.co.uk/login', { waitUntil: 'networkidle2' });

    console.log('Loaded login page');

    await page.type('#email', process.env.VA_USERNAME);
    await page.type('#password', process.env.VA_PASSWORD);
    await page.click('button[type="submit"]');

    await page.waitForNavigation({ waitUntil: 'networkidle2' });

    console.log('Logged in');

    // ⬇️ You can now add booking logic here

    return {
      statusCode: 200,
      body: JSON.stringify('Booking attempted'),
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify(error.message || 'Unknown error'),
    };
  } finally {
    if (browser !== null) {
      await browser.close();
    }
  }
};